//
//  Color + Ext.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 16/04/24.
//

import SwiftUI

struct colorTheme{
    let accent = Color("Accent")
    let background = Color("Background")
    let green = Color("Green")
    let purple = Color("Purple")
    let secondory = Color("Secondory")
    let secondory2 = Color("Secondory2")
    let secondyText = Color("SecondyText")
    let slider = Color("Slider")
}

extension Color{
    static let theme = colorTheme()
}
