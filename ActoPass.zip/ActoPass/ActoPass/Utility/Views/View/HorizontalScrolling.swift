//
//  Horizontal Scrolling.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct HorizontalScrolling: View {
    
    var items : Int = 5
    @State var currentIndex = 0
    
    var body: some View {
        VStack {
            ScrollView(.horizontal){
                ScrollViewReader(content: { proxy in
                    HStack{
                        ForEach(0..<items){index in
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.theme.secondory)
                                .frame(width: 320, height: 180)
                                .id(index)
                            
                        }
                    }
                    .onChange(of: currentIndex) { oldValue, newValue in
                        withAnimation {
                            proxy.scrollTo(newValue, anchor: .center)
                        }
                        
                        
                    }
                })
            }
            .onAppear{
                Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { timer in
                    withAnimation {
                        if currentIndex + 1 == items {
                            currentIndex = 0
                        }else{
                            currentIndex += 1
                        }
                    }
                }
            }
            HStack{
                ForEach(0..<items){index in
                    RoundedRectangle(cornerRadius: 3.5)
                        .fill(currentIndex == index ? Color.theme.slider : Color.theme.secondory)
                        .frame(width: currentIndex == index ? 20 : 7 ,height: 7)
                }
            }
            .padding()
            
        }
    }
}

#Preview {
    HorizontalScrolling()
}
