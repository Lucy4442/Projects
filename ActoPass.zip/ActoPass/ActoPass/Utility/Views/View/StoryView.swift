//
//  StoryView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct StoryView: View {
    @State var currentIndex = 0
    @State var width : CGFloat = 0
    var stortes = 5
    var body: some View {
        ZStack{
            Rectangle()
                .fill(Color.theme.secondory)
            Text("story\(currentIndex)")
            VStack{
                Rectangle()
                    .fill(Color.theme.purple)
                    .frame(maxWidth: width)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.white)
                    .frame(height: 2)
                Spacer()
            }
            .padding()
        }
        .background(Color.theme.secondory)
        .onAppear{
            withAnimation(.easeInOut(duration: 5)) {
                width = .infinity
            }
            
            Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { timer in
                
                width = 0
                
                withAnimation(.easeInOut(duration: 5)) {
                    if self.currentIndex + 1 == stortes {
                        self.currentIndex = 0
                    }else{
                        self.currentIndex += 1
                    }
                    width = .infinity
                }
            }
            
            
        }
    }
}

#Preview {
    StoryView()
}
