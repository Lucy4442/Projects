//
//  BookNow.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 18/04/24.
//

import SwiftUI

struct BookNow: View {
    
    var items : Int = 5
    @State var currentIndex = 0
    @Binding var bookNow : Bool
    
    var body: some View {
        VStack{
            ScrollView(.horizontal,showsIndicators: false){
            ScrollViewReader{ proxy in
                HStack{
                    ForEach(0..<items){ index in
                        VStack{
                            HStack(alignment: .top, spacing: 15 ){
                                Image(systemName: "photo")
                                    .frame(width: 150, height: 200)
                                    .background(Color.theme.secondory2)
                                    .foregroundStyle(.secondyText)
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                                
                                VStack(alignment:.leading,spacing: 10){
                                    Text("Lorem ipsum")
                                        .font(.title3)
                                        .fontWeight(.heavy)
                                    
                                    Text("1h 51m  |  Horror, Mystery, Thriller  |  A")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondyText)
                                    
                                    Text("English, Hindi, Tamil, Telugu")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondyText)
                                    
                                    Text("The sequel to the worldwide smash hit follows Sister Irene as...")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondyText)
                                }
                            }
                            .padding(.horizontal, 15)
                            .frame(height: 200)
                            
                            Button{
                                bookNow.toggle()
                            } label: {
                                HStack{
                                    Image(systemName: "cart")
                                    Text("Book Now")
                                }
                                .frame(maxWidth: .infinity)
                                .frame(height: 46)
                                .foregroundStyle(.white)
                                .background(Color.theme.purple)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                .padding()
                                
                                
                            }
                        }
                        .id(index)
                        .frame(width: UIScreen.main.bounds.width)
                        .onChange(of: currentIndex) { oldValue, newValue in
                            withAnimation {
                                proxy.scrollTo(newValue, anchor: .center)
                            }
                            
                        }
                    }
                }
            }
        }
            
            HStack{
                ForEach(0..<items){index in
                    RoundedRectangle(cornerRadius: 3.5)
                        .fill(currentIndex == index ? Color.theme.slider : Color.theme.secondyText)
                        .frame(width: currentIndex == index ? 15 : 7 ,height: 7)
                }
            }
            
            
        }
        .frame(maxWidth: .infinity)
        .frame(height: 331)
        .background(Color.theme.secondory)
        .onAppear{
            Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { timer in
                withAnimation {
                    if currentIndex + 1 == items {
                        currentIndex = 0
                    }else{
                        currentIndex += 1
                    }
                }
            }
        }
        
    }
    
}

#Preview {
    BookNow(bookNow: .constant(false))
}
