//
//  TicketView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 19/04/24.
//

import SwiftUI

struct TicketCardView: View {
    var ticketType : String
    @State var ticketDetails = false
    @Binding var noOfTickets : Int
    var body: some View {
        VStack(alignment:.leading){
            HStack(alignment:.top){
                VStack(alignment:.leading){
                    Text(ticketType)
                        .font(.title2)
                        .bold()
                        .foregroundStyle(Color.theme.accent)
                    HStack{
                        Text("$8.00")
                            .font(.title3)
                            .bold()
                            .foregroundStyle(Color.theme.accent)
                        Text("/ Per Person")
                            .font(.caption)
                            .foregroundStyle(Color.theme.secondyText)
                    }
                }
                Spacer()
                if noOfTickets <= 0 {
                    Button{
                        withAnimation {
                            noOfTickets = 1
                        }
                        
                    }label: {
                        Text("Add")
                            .bold()
                            .font(.title3)
                            .padding(.vertical,5)
                            .padding(.horizontal)
                            .foregroundStyle(Color.theme.accent)
                            .background{
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(lineWidth: 1)
                                    .fill(Color.theme.purple)
                            }
                        
                        
                    }
                }else{
                    HStack{
                        Button{
                            noOfTickets += 1
                        }label: {
                            Image(systemName: "plus.circle")
                                .foregroundStyle(.white)
                                .font(.title2)
                        }
                        Text("\(noOfTickets)")
                            .font(.title3)
                            .bold()
                            .padding(.horizontal,5)
                        Button{
                            noOfTickets -= 1
                        }label: {
                            Image(systemName: "minus.circle")
                                .foregroundStyle(.white)
                                .font(.title)
                        }
                    }
                    .padding(.vertical,5)
                    .padding(.horizontal,8)
                    .background(Color.theme.purple)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                }
            }
            
            Button{
                withAnimation {
                    ticketDetails.toggle()
                }
                
            }label: {
                HStack{
                    Text("Details")
                    Image(systemName: "chevron.down" )
                        .rotationEffect(Angle(degrees: ticketDetails ? 180 : 0))
                }
                .foregroundStyle(Color.theme.purple)
                .bold()
                .padding(.top,3)
            }
            
            if ticketDetails{
                HStack(alignment:.top){
                    Image("tick-circle")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 25)
                    Text("Each ticket will allow entry to 1 person in Lower Balcony zone.")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                }
                HStack(alignment:.top){
                    Image("tick-circle")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 25)
                    Text("Seating will be on first come first serve basis.")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                }
            }
            
        }
        .padding()
        .background(Color.theme.secondory)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .offset(x:2)
        .background(Color.theme.purple)
        .clipShape(RoundedRectangle(cornerRadius: 11))
        
    }
}

#Preview {
    TicketCardView(ticketType: "SILVER", noOfTickets: .constant(0))
}
