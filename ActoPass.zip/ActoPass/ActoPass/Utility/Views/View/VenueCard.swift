//
//  VenueCard.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 19/04/24.
//

import SwiftUI

struct VenueCard: View {
    
    @Binding var showSelectVenue : Bool
    
    var body: some View {
        VStack(alignment:.leading,spacing: 5){
            Text("HK Hall: Ahemdabad")
                .font(.title2)
                .bold()
                .foregroundStyle(Color.theme.accent)
            Text("14 September,2023 | 9:00 PM to 12:00 PM")
                .font(.headline)
                .foregroundStyle(Color.theme.accent)
            Text("New Barakhamba Rd, Connaught Lane, Barakhamba, New Delhi, Delhi 110001")
                .font(.subheadline)
                .foregroundStyle(Color.theme.secondyText)
            HStack{
                Button{
                    showSelectVenue.toggle()
                } label: {
                    HStack{
                        Image(systemName: "cart")
                        Text("Book Now")
                    }
//                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .foregroundStyle(.white)
                    .padding(.horizontal)
                    .background(Color.theme.purple)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.vertical)
                    
                    
                }
                
                Button{
                    
                } label: {
                    HStack{
                        Image(systemName: "dot.scope")
                        Text("View Map")
                    }
//                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .foregroundStyle(Color.theme.secondyText)
                    .padding(.horizontal)
                    .background(Color.theme.secondory)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.vertical)
                    
                }
                Spacer()
            }
            
        }
    }
}

#Preview {
    VenueCard(showSelectVenue: .constant(true))
}
