//
//  Date&TimeView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 19/04/24.
//

import SwiftUI

struct Date_TimeView: View {
    
    @State var selectedTime = 0
    
    var body: some View {
        VStack(alignment : .leading){
            VStack(alignment : .leading){
                Text("SUN,18 SEPTEMBER")
                    .font(.headline)
                    .bold()
                    .foregroundStyle(Color.theme.accent)
                
                Button{
                    selectedTime = 0
                }label: {
                    Text("05:00 PM")
                        .font(.headline)
                        .foregroundStyle(selectedTime == 0 ? .white : Color.theme.secondyText)
                        .padding()
                        .background(selectedTime == 0 ? Color.theme.purple : .clear)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .overlay(
                            selectedTime != 0 ?
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(lineWidth: 1)
                                    .fill(Color.theme.secondyText) : nil
                            
                        )
                }
                .padding(.top)
            }
            VStack(alignment : .leading){
                Text("SUN,19 SEPTEMBER")
                    .font(.headline)
                    .bold()
                    .foregroundStyle(Color.theme.accent)
                
                Button{
                    selectedTime = 1
                }label: {
                    Text("09:00 AM")
                        .font(.headline)
                        .foregroundStyle(selectedTime == 1 ? .white : Color.theme.secondyText)
                        .padding()
                        .background(selectedTime == 1 ? Color.theme.purple : .clear)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .overlay(
                            selectedTime != 1 ?
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(lineWidth: 1)
                                    .fill(Color.theme.secondyText) : nil
                            
                        )
                        
                }
                .padding(.top)
            }
            .padding(.vertical,30)
        }
        .frame(maxWidth: .infinity,alignment: .leading)
        
        
    }
}

#Preview {
    Date_TimeView()
}
