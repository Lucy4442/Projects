//
//  SponsorCard.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 18/04/24.
//

import SwiftUI

struct SponsorCard: View {
    let sponsors : [Image]
    let width = UIScreen.main.bounds.width/2 - 30
    var body: some View {
        
        ForEach(0..<sponsors.count){ index in
            VStack{
                sponsors[index]
                    .resizable()
                    .frame(width: 72, height: 72)
                Text("Gladyce")
                    .font(.subheadline)
                    .foregroundStyle(.accent)
                    .padding(.top,1)
            }
            
            .frame(width: width, height: width - 8)
            .background(Color.theme.secondory)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            
        }
    }
}

#Preview {
    SponsorCard(sponsors: [Image("Sponsor1")])
}
