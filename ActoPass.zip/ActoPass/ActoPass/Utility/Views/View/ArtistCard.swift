//
//  ArtistCard.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 18/04/24.
//

import SwiftUI

struct ArtistCard: View {
    
    let avatars : [Image]
    var isArtist : Bool
    @State var isArtistDetailShow = false
    var body: some View {
        ForEach(0..<avatars.count){ index in
            
                NavigationLink {
                    if isArtist{
                        ArtistDetailView(artistImg: avatars[index], artistName: "Gladyce")
                    }else{
                        OrganizerDetailsView(organizerImage: avatars[index], organizerName: "Gladyce")
                    }
                } label: {
                    VStack{
                    avatars[index]
                        .resizable()
                        .frame(width: 64, height: 64)
                    Text("Gladyce")
                        .font(.subheadline)
                        .foregroundStyle(.accent)
                        .padding(.top,1)
                }
                    .padding()
                    .background(Color.theme.secondory)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                
            }
            
        }
    }
}

#Preview {
    ArtistCard(avatars: [Image("Avatar"),Image("Avatar2")], isArtist: true)
}
