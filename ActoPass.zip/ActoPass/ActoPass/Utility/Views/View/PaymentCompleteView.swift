//
//  PaymentCompleteView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 22/04/24.
//

import SwiftUI

struct PaymentCompleteView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @State var isCompleted = false
    @State var isShow = false
    var body: some View {
            VStack{
                header
                    .padding(.horizontal)
                Spacer()
                ZStack{
                    Image("PaymentComplete")
                        .rotationEffect(.degrees(isCompleted ? 360 : 0))
                    if !isShow{
                        Image("Tick")
                    }else{
                        Image("CompletedTick")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: isCompleted ? 100 : 0)
                    }
                }
                
                
                VStack{
                    Text("Lorem Ipsum")
                        .font(.title)
                        .fontWeight(.semibold)
                    
                    Text("Lorem ipsum dolar sit amet, consectetur \nadipiscing elit.")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                }
                .padding(.vertical,20)
                
                Button{
                    
                }label: {
                    Text("Continue")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundStyle(Color.theme.accent)
                        .padding(.vertical)
                        .padding(.horizontal,60)
                        .background(isCompleted ? Color.theme.purple : Color.theme.secondory)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    
                }
                Spacer()
            }
            .onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now() + 3){
                    isShow.toggle()
                    withAnimation(.spring(duration: 3)){
                        isCompleted.toggle()
                    }
                }
            }
            .toolbar(.hidden)
        
    }
    
}

#Preview {
    PaymentCompleteView()
}

extension PaymentCompleteView {
    private var header: some View{
        
        ZStack{
            HStack{
                Button{
                    presentationMode.wrappedValue.dismiss()
                }label: {
                    Image(systemName: "arrow.left")
                        .foregroundStyle(Color.theme.accent)
                        .font(.title2)
                }
                Spacer()
            }
        }
        
    }
    
}
