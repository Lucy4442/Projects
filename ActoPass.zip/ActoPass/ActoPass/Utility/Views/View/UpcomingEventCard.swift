//
//  UpcomingEventCard.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 18/04/24.
//

import SwiftUI

struct UpcomingEventCard: View {
    let width = UIScreen.main.bounds.width/2 - 30
    let height = (UIScreen.main.bounds.width/2 - 30)*4/3
    var body: some View {
        VStack{
            Rectangle()
                .fill(Color.theme.secondory2)
                .frame(height: height*3/4)
            
            Spacer()
            VStack(alignment: .leading,spacing: 3){
                Text("Bar Crawl,Gurgaon")
                    .font(.footnote)
                    .bold()
                Text("Grizly X Times Prime")
                    .font(.caption2)
                    .foregroundStyle(Color.theme.secondyText)
            }
            Spacer()
        }
        .frame(width: width , height: height)
        .background(Color.theme.secondory)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    UpcomingEventCard()
}
