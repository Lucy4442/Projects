//
//  CardView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 18/04/24.
//

import SwiftUI

struct CardView: View {
    
    var cardColor : Color
    
    var body: some View {
        VStack{
            VStack(spacing:0){
                ZStack(alignment: .top){
                    
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.theme.secondory)
                        .frame(width: 116,height:110)
                        .offset(y: 2)
                        
                    Circle()
                        .frame(width: 38, height: 38)
                        .overlay{
                            Circle()
                                .stroke(lineWidth: 2)
                                .fill(Color.theme.secondory)
                        }
                        .offset(y: 93)
                        
                }
                Spacer()
                Spacer()
                Text("1 Year")
                    .bold()
                Spacer()
            }
            .frame(width: 120,height: 170)
            .background(cardColor)
            .clipShape(RoundedRectangle(cornerRadius: 12))
            
            Text("Lorem ipsum")
                .font(.subheadline)
                .foregroundStyle(Color.theme.secondyText)
                .padding(.vertical,5)
        }
    }
}

#Preview {
    CardView(cardColor: Color.theme.purple)
}
