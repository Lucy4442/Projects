//
//  TicketDetail.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 22/04/24.
//

import SwiftUI

struct TicketDetail: View {
    
    @State var showPaymentCompletion = false
    
    var body: some View {
        ScrollView(showsIndicators : false) {
            VStack(spacing : 20) {
                
                Ticket()
                ContactDetails()
                DiscountCode()
                PaymentMethod()
                
//                Button{
//                    
//                }label: {
//                    Text("Pay $8.00")
//                        .font(.title2)
//                        .fontWeight(.semibold)
//                        .foregroundStyle(Color.theme.accent)
//                        .frame(maxWidth: .infinity)
//                        .padding()
//                        .background(Color.theme.purple)
//                        .clipShape(RoundedRectangle(cornerRadius: 10))
//                }
//                .padding(.vertical)
                
                Button{
                    showPaymentCompletion.toggle()
                }label: {
                    Text("Continue")
                        .font(.title3)
                        .foregroundStyle(Color.theme.accent)
                        .frame(height: 50)
                        .frame(maxWidth: .infinity)
                        .background(Color.theme.purple)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        
                    
                }
                .padding(.vertical)
            }
        }
        .navigationDestination(isPresented: $showPaymentCompletion) {
            PaymentCompleteView()
        }
        
    }
}

struct Line: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 0, y: 0))
        path.addLine(to: CGPoint(x: rect.width, y: 0))
        return path
    }
}


#Preview {
    TicketDetail()
}

struct Ticket: View {
    var body: some View {
        VStack{
            
            Spacer()
            
            HStack {
                VStack(alignment : .leading) {
                    Text("Bar Crawl, Gurgon")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundStyle(Color.theme.accent)
                    
                    Text("14 September,2023 | 9:00 PM")
                        .font(.caption)
                        .foregroundStyle(Color.theme.secondyText)
                }
                Spacer()
                Text("$8.00")
                    .font(.title2)
                    .fontWeight(.semibold)
            }
            
            Spacer()
            
            VStack(alignment : .leading){
                HStack(alignment: .top){
                    Image("Pin")
                        .padding(.top,5)
                    VStack(alignment: .leading){
                        Text("New Delhi")
                            .font(.title3)
                            .bold()
                        
                        Text("New Barakhamba Rd, Connaught Lane, Barakhamba, New Delhi, Delhi 110001")
                            .font(.subheadline)
                            .foregroundStyle(Color.theme.secondyText)
                    }
                }
                
            }
            .frame(maxWidth: .infinity,alignment:.leading)
            .padding()
            .background(Color.theme.secondory2)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            
            
            
            Line()
                .stroke(style: StrokeStyle(lineWidth: 1,dash: [5]))
                .frame(height: 1)
                .background(.clear)
                .foregroundStyle(Color.theme.secondyText)
                .padding(.horizontal,10)
                .padding(.vertical)
                .offset(y:5)
            
            
            
            Text("Sliver ($8.00) : 2 Tickets")
                .font(.title3)
                .foregroundStyle(Color.theme.secondyText)
            Spacer()
            
            
        }
        .padding(.horizontal)
        .background(Image("Subtract")
            .resizable()
            .frame(height: 260)
            .foregroundStyle(Color.theme.secondory))
        
        .frame(height: 260)
        
    }
}

struct ContactDetails: View {
    var body: some View {
        VStack(alignment : .leading){
            HStack{
                Text("Contact Details")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundStyle(Color.theme.accent)
                    .padding(.horizontal)
                    .overlay(alignment:.topLeading) {
                        RoundedRectangle(cornerRadius: 2)
                            .fill(Color.theme.purple)
                            .frame(width: 5,height: 24)
                    }
            }
            VStack(alignment:.leading){
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical,5)
                
                Text("+91 258369147")
                    .font(.headline)
                    .foregroundStyle(Color.theme.secondyText)
            }
            .padding(.horizontal)
        }
        .padding(.vertical)
        .background(Color.theme.secondory)
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

struct DiscountCode: View {
    var body: some View {
        HStack{
            VStack(alignment: .leading){
                Text("Discount Code")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundStyle(Color.theme.accent)
                    .padding(.horizontal)
                    .overlay(alignment:.topLeading) {
                        RoundedRectangle(cornerRadius: 2)
                            .fill(Color.theme.purple)
                            .frame(width: 5,height: 24)
                        }
                    .padding(.bottom,10)
                Text("xxx xxx")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundStyle(Color.theme.secondyText)
                    .padding(.horizontal)
            }
            .frame(maxWidth: .infinity,alignment: .leading)
            
            Button{
                
            }label: {
                Image("Share")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 33,height: 33)
                    .padding(.trailing,20)
            }
        }
        .padding(.vertical)
        .background(Color.theme.secondory)
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

struct PaymentMethod: View {
    var body: some View {
        HStack{
            VStack(alignment: .leading){
                Text("Choose Payment Method")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundStyle(Color.theme.accent)
                    .padding(.horizontal)
                    .overlay(alignment:.topLeading) {
                        RoundedRectangle(cornerRadius: 2)
                            .fill(Color.theme.purple)
                            .frame(width: 5,height: 24)
                    }
                    .padding(.bottom,10)
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical,5)
                    .padding(.horizontal)
                
                HStack(spacing : 10){
                    Image("Paytm")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 28,height: 28)
                    
                    VStack(alignment: .leading){
                        Text("Paytm")
                        Text("(Wallet | UPI | Saved Cards)")
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                }
                .padding(.horizontal)
                
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical,5)
                    .padding(.horizontal)
                
                HStack(spacing : 10){
                    Image("upi")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 28,height: 28)
                    
                    Text("UPI")
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                }
                .padding(.horizontal)
                
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical,5)
                    .padding(.horizontal)
                
                HStack(spacing : 10){
                    Image("card")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 28,height: 28)
                    
                    Text("Debit / Credit Card")
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                }
                .padding(.horizontal)
                
            }
            .frame(maxWidth: .infinity,alignment: .leading)
            
        }
        .padding(.vertical)
        .background(Color.theme.secondory)
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

