//
//  ProfileNavigationView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct ProfileNavigationView: View {
    var body: some View {
        HStack{
            Image("ProfileImg")
                .resizable()
                .frame(width:38,height: 38)
                .clipShape(RoundedRectangle(cornerRadius: 19))
            VStack(alignment: .leading){
                HStack{
                    Text("Around You")
                    Image(systemName: "chevron.down")
                }
                .font(.caption)
                .foregroundStyle(Color.theme.secondyText)
                
                Text("Hyderabad")
                    .font(.title3)
                    .bold()
            }
            
            Spacer()
            
            Button{
                
            }label: {
                Image("SearchBtn")
            }
            
            Button{
                
            }label: {
                Image("Ellipse")
                    .overlay {
                        Image("notification")
                    }
            }
        }
    }
}

#Preview {
    ProfileNavigationView()
}
