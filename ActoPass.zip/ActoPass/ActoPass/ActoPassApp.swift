//
//  ActoPassApp.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 16/04/24.
//

import SwiftUI

@main
struct ActoPassApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
