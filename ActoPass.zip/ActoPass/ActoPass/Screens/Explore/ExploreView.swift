//
//  ExploreView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct ExploreView: View {
    var body: some View {
        Text("Hello, Explore!")
    }
}

#Preview {
    ExploreView()
}
