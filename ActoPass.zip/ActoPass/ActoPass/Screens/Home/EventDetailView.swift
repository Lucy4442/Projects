//
//  EventDetailView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 18/04/24.
//

import SwiftUI

struct EventDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var showListOfVenue = false
    let column : [GridItem] = [GridItem(.flexible()),GridItem(.flexible())]
    var body: some View {
//        ScrollView{
            ZStack{
                ScrollView{
                VStack(alignment:.leading){
                    Image("Event")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                    
                    title
                    
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    
                    address
                    
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    
                    moreInfo
                    
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    
                    artist
                    
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    
                    organization
                    
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    
                    sponsor
                    
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    
                    note
                    
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    
                    termAndCondition
                    
                    Spacer(minLength: 140)
                }
                
                
            }
            
                navigation
                    .padding(.top,40)
        }
        .ignoresSafeArea(edges:.vertical)
        .toolbar(.hidden)
    }
}

#Preview {
    EventDetailView()
}

extension EventDetailView{
    private var navigation: some View{
        VStack{
            HStack{
                Button{
                    presentationMode.wrappedValue.dismiss()
                }label: {
                    Image("Back")
                }
                Spacer()
                Button{
                    
                }label: {
                    Image("Share")
                }
            }
            .padding()
            Spacer()
            
            HStack{
                VStack(alignment:.leading){
                    Text("Starting from")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.accent)
                        .bold()
                    Text("Per Person")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                    
                    Text("$8.00")
                        .font(.title)
                        .foregroundStyle(Color.theme.accent)
                        .bold()
                        .padding(.top,1)
                }
                
                Button{
                    
                } label: {
                    HStack{
                        Image(systemName: "cart")
                        Text("Book Now")
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .foregroundStyle(.white)
                    .background(Color.theme.purple)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding()
                    
                    
                }
            }
            .padding()
            .background(Color.theme.secondory)
            .clipShape(RoundedRectangle(cornerRadius: 17))
            
        }
    }
    
    private var title: some View{
        VStack(alignment: .leading,spacing: 12){
            Text("Comedy Shows")
                .foregroundStyle(Color.theme.secondyText)
                .padding(10)
                .background(Color.theme.secondory)
                .clipShape(RoundedRectangle(cornerRadius: 7))
            
            Text("Bar Crawl, Gurgaon")
                .font(.title2)
                .bold()
            
            Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the...")
                .font(.subheadline)
                .foregroundStyle(Color.theme.secondyText)
            
            HStack{
                Image("menu")
                Text("14 September,2023")
                Image("ArrowHorizontal")
                Text("24 September,2023")
                
            }
            .font(.subheadline)
            .foregroundStyle(Color.theme.secondyText)
            .padding(7)
            .background(Color.theme.secondory)
            .clipShape(RoundedRectangle(cornerRadius: 5))
            
            HStack{
                Image("clock")
                Text("9:00 PM to 12:00 PM")
                
                
            }
            .font(.subheadline)
            .foregroundStyle(Color.theme.secondyText)
            .padding(7)
            .background(Color.theme.secondory)
            .clipShape(RoundedRectangle(cornerRadius: 5))
        }
        .padding(10)
    }
    
    private var address: some View{
        VStack(alignment:.leading){
            Text("ADDRESS")
                .font(.subheadline)
                .foregroundStyle(Color.theme.accent)
                .bold()
            
            HStack(alignment:.top){
                Image("Pin")
                VStack(alignment:.leading){
                    Text("New Delhi")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.accent)
                        .bold()
                        .frame(maxWidth: .infinity,alignment: .leading)
                    Text("New Barakhamba Rd, Connaught Lane, Barakhamba, New Delhi, Delhi 110001")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                    
                }
                
            }
            .padding()
            .background(Color.theme.secondory)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            
            Button{
                showListOfVenue.toggle()
            }label: {
                Text("3 more venues >")
                    .font(.subheadline)
                    .bold()
                    .foregroundStyle(Color.theme.purple)
                    .underline()
            }
        }
        .padding(.horizontal)
        .navigationDestination(isPresented: $showListOfVenue) {
            VenueListView()
        }
    }
    
    private var moreInfo: some View{
        VStack(alignment : .leading){
            Text("MORE INFORMATION")
                .font(.subheadline)
                .bold()
                .padding(.bottom,10)
                .foregroundStyle(Color.theme.accent)
            Text("Comedy")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .padding(.bottom,10)
            VStack(alignment : .leading){
                HStack {
                    Image(systemName: "clock")
                        .foregroundColor(.secondary)
                    Text("1hr 30mins")
                }
                HStack {
                    Image("Language")
                        .foregroundColor(.secondary)
                    Text("Hindi")
                }
                HStack {
                    Image("profiletick")
                    Text("16yrs +")
                }
            }
            .font(.subheadline)
            .foregroundStyle(Color.theme.secondyText)
            
        }
        .padding(.horizontal)
    }
    
    private var artist: some View{
        VStack(alignment:.leading){
            Text("ARTIST")
                .font(.subheadline)
                .foregroundStyle(Color.theme.accent)
                .bold()
            
                ScrollView(.horizontal){
                    HStack{
                        ArtistCard(avatars: [Image("Avatar"),Image("Avatar2"),Image("Avatar"),Image("Avatar2"),Image("Avatar"),Image("Avatar2")])
                    }
                }
                .padding(.vertical)
            
            Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the")
                .font(.subheadline)
                .foregroundStyle(Color.theme.secondyText)
            
        }
        .padding(.horizontal)
    }
    
    private var organization: some View{
        VStack(alignment:.leading){
            Text("ORGANIZATION")
                .font(.subheadline)
                .foregroundStyle(Color.theme.accent)
                .bold()
            
                ScrollView(.horizontal){
                    HStack{
                        ArtistCard(avatars: [Image("Avatar"),Image("Avatar2")])
                    }
                }
                .padding(.vertical)
            
            Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the")
                .font(.subheadline)
                .foregroundStyle(Color.theme.secondyText)
            
        }
        .padding(.horizontal)
    }
    
    private var sponsor: some View{
        
        VStack(alignment:.leading){
            Text("SPONSOR")
                .font(.subheadline)
                .foregroundStyle(Color.theme.accent)
                .bold()
                .padding(.bottom)
            
            LazyVGrid(columns: column,spacing: 17) {
               SponsorCard(sponsors: [Image("Sponsor1"),Image("Sponsor2"),Image("Sponsor3"),Image("Sponsor4"),Image("Sponsor5"),Image("Sponsor6")])
            }
        }
        .padding(.horizontal)
    }
    
    private var note: some View{
        VStack(alignment:.leading){
            Text("NOTE")
                .font(.subheadline)
                .foregroundStyle(Color.theme.accent)
                .bold()
            
            Text("Seating is on a first come first serve basis in that respective section.")
                .font(.subheadline)
                .foregroundStyle(Color.theme.secondyText)
            
        }
        .padding(.horizontal)
    }
    
    private var termAndCondition: some View{
        HStack{
            Text("Term & Conditions")
                .font(.subheadline)
                .foregroundStyle(Color.theme.accent)
                .bold()
            Spacer()
            Image("RightArrow")
                .foregroundStyle(Color.theme.accent)
            
        }
        .padding(.horizontal)
    }
}
