//
//  OrganizerDetailsView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 22/04/24.
//

import SwiftUI

struct OrganizerDetailsView: View {
    
    @Environment(\.dismiss) var dismiss
    var organizerImage : Image
    var organizerName : String
    var body: some View {
        VStack{
            header
                .padding()
            organizerImage
                .resizable()
                .scaledToFit()
                .frame(width: 87,height: 87)
                .padding(.vertical)
            Text(organizerName)
                .font(.title3)
                .fontWeight(.semibold)
//                .padding()

            CompanyDetail
                .padding(.top)
            
            Spacer()
        }
        .toolbar(.hidden)
    }
}

#Preview {
    OrganizerDetailsView(organizerImage: Image("Sponsor1"), organizerName: "Glayde")
}

extension OrganizerDetailsView {
    private var header: some View{
        
        ZStack{
            HStack{
                Button{
                    dismiss.callAsFunction()
                }label: {
                    Image(systemName: "arrow.left")
                        .foregroundStyle(Color.theme.accent)
                        .font(.title2)
                }
                Spacer()
            }
            
            Text("Organizer Details")
                .font(.title2)
                .bold()
            
        }
        
    }
    
    private var CompanyDetail : some View {
        VStack{
            HStack(alignment : .top){
                Image(systemName: "phone")
                    .font(.headline)
                    .foregroundStyle(Color.theme.secondyText)
                    .padding(.vertical,5)
                    .padding(.horizontal,10)
                
                VStack(alignment : .leading){
                    Text("Mobile No")
                        .font(.headline)
                        .foregroundStyle(Color.theme.secondyText)
                    Text("+91 25252 25352")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundStyle(Color.theme.accent)
                }
                .frame(maxWidth: .infinity,alignment: .leading)
            }
            
            Divider()
                .frame(height: 1)
                .background(Color.theme.secondory)
                .padding(.vertical,5)
                .padding(.horizontal)
            
            HStack(alignment : .top){
                Image(systemName: "envelope")
                    .font(.headline)
                    .foregroundStyle(Color.theme.secondyText)
                    .padding(.vertical,5)
                    .padding(.horizontal,10)
                
                VStack(alignment : .leading){
                    Text("Email ID")
                        .font(.headline)
                        .foregroundStyle(Color.theme.secondyText)
                    Text("gladyacejake@gmail.com")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundStyle(Color.theme.accent)
                }
                .frame(maxWidth: .infinity,alignment: .leading)
            }
            
            Divider()
                .frame(height: 1)
                .background(Color.theme.secondory)
                .padding(.vertical,5)
                .padding(.horizontal)
            
            
            HStack(alignment : .top){
                Image(systemName: "building.2")
                    .font(.headline)
                    .padding(.vertical,5)
                    .padding(.horizontal,10)
                    .foregroundStyle(Color.theme.secondyText)
                
                VStack(alignment : .leading){
                    Text("Company Name")
                        .font(.headline)
                        .foregroundStyle(Color.theme.secondyText)
                    Text("Gladyce jake")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundStyle(Color.theme.accent)
                }
                .frame(maxWidth: .infinity,alignment: .leading)
            }
            
            Divider()
                .frame(height: 1)
                .background(Color.theme.secondory)
                .padding(.vertical,5)
                .padding(.horizontal)
            
            VStack(alignment : .leading){
                Text("Description".uppercased())
                    .font(.headline)
                    .fontWeight(.semibold)
                Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the and industry's standard dummy ")
                    .font(.subheadline)
                    .foregroundStyle(Color.theme.secondyText)
            }
            .frame(maxWidth: .infinity,alignment: .leading)
            .padding(.vertical,10)
            .padding(.horizontal)
            
        }
    }
}
