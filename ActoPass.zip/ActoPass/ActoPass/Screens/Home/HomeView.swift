//
//  HomeView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct HomeView: View {
   
    let columns : [GridItem] = [GridItem(.flexible()),GridItem(.flexible())]
    
    let colorArr  = [Color.theme.purple, Color(uiColor: #colorLiteral(red: 0.3186992407, green: 0.2891896367, blue: 0.9490255713, alpha: 1)), Color(#colorLiteral(red: 0.7473981977, green: 0.3588457108, blue: 0.2601557672, alpha: 1))]
    
    let categories = ["All","Party","Seminar","Sport","Bussiness","Stand up Comedy", "Singing"]
    @State var selectedCategory = 0
    @State var bookNow = false
    
    var body: some View {
        VStack{
            ProfileNavigationView()
                .padding(.horizontal)
            ScrollView(showsIndicators:false){
                    VStack(spacing:0){
                    
                    StoryView()
                        .frame(height: 568)
                        .background(.white)
                    
                    HorizontalScrolling()
                        .padding(.top)
                    
                    bannerView
                    
                    justForYou
                    
                    cards
                        .padding(.top)
                    
                    stream
                       
                        BookNow(bookNow: $bookNow)
                        
                    eventGridView
                        
                }
                .navigationDestination(isPresented: $bookNow) {
                    EventDetailView()
                }
                
            
        }
        }
    }
}

#Preview {
    HomeView()
}

extension HomeView{
    private var bannerView: some View{
        ZStack{
            Rectangle()
                .frame(maxWidth: .infinity)
                .frame(height: 130)
                .foregroundStyle(Color.theme.secondory)
            Text("Announcement Banner")
                .font(.subheadline)
                .bold()
                .foregroundStyle(Color.theme.accent)
        }
        .padding(.bottom)
    }
    
    private var justForYou: some View{
        VStack(spacing:5){
            Text("Lorem ipsum dolor sit amet, consectetur")
                .font(.subheadline)
                .foregroundStyle(Color.theme.secondyText)
                .padding(.top)
            Image("JustForYou")
                
        }
    }
    
    private var cards: some View{
        ScrollView(.horizontal){
            HStack(spacing: 20){
                ForEach(0..<5){index in
                    CardView(cardColor: colorArr[index % 3])
                }
            }
        }
    }
    
    private var stream: some View{
        ZStack{
            Image("Stream")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(maxWidth: .infinity)
            
            HStack{
                VStack{
                    Text("STREAM")
                        .fontWeight(.heavy)
                        .font(.title3)
                    Image("StreamVector")
                }
                
                Spacer()
                
                Text("Endless Entertainment. \nAnytime. Anywhere!")
                    .font(.subheadline)
                    .bold()
                    .foregroundStyle(.yellow)
            }
            .padding(20)
        }
        .background(Color.theme.secondory)
        .padding(.top)
    }

    private var eventGridView: some View{
        VStack(alignment:.leading, spacing: 19){
            Text("Upcoming Events")
                .font(.title2)
                .bold()
            ScrollView(.horizontal,showsIndicators: false){
                HStack{
                    ForEach(0..<categories.count){index in
                        
                            Button{
                                selectedCategory = index
                            }label: {
                                Text(categories[index])
                                    .padding(10)
                                    .foregroundStyle(selectedCategory == index ?.white : .secondyText)
                                    .background(selectedCategory == index ? Color.theme.purple : Color.theme.secondory)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                    
                                
                            }
                        
                    }
                }
            }
            
            LazyVGrid(columns: columns,spacing:15) {
                ForEach(0..<6){index in
                        UpcomingEventCard()
                }
            }
        }
        .padding()
    }
    
}
