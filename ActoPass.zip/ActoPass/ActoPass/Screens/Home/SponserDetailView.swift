//
//  SponserDetailView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 22/04/24.
//

import SwiftUI

struct SponserDetailView: View {
    @Environment(\.dismiss) var dismiss
    var SponserImg : Image
    var SponserName : String
    var body: some View {
        
        VStack{
            header
                .padding()
            SponserImg
                .resizable()
                .scaledToFit()
                .frame(width: 87,height: 87)
                .padding(.vertical)
           
            Text(SponserName)
                .font(.headline)
                .fontWeight(.semibold)
            
            ScrollView {
                VStack(alignment : .leading,spacing: 10){
                    Text("SPONSER TITLE")
                        .font(.headline)
                        .fontWeight(.semibold)
                    Text("Lorem jasum")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                }
                .frame(maxWidth: .infinity,alignment: .leading)
                .padding(.vertical,10)
                .padding(.horizontal)
                
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical,5)
                    .padding(.horizontal)
                
                VStack(alignment : .leading,spacing: 10){
                    Text("SPONSER NAME")
                        .font(.headline)
                        .fontWeight(.semibold)
                    Text("Lorem jasum")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                }
                .frame(maxWidth: .infinity,alignment: .leading)
                .padding(.vertical,10)
                .padding(.horizontal)
                
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical,5)
                    .padding(.horizontal)
                
                VStack(alignment : .leading,spacing: 10){
                    Text("SPONSER")
                        .font(.headline)
                        .fontWeight(.semibold)
                    Text("Event Sponser, Co-Sponser")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                }
                .frame(maxWidth: .infinity,alignment: .leading)
                .padding(.vertical,10)
                .padding(.horizontal)
                
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical,5)
                    .padding(.horizontal)
                
                VStack(alignment : .leading,spacing: 10){
                    Text("DESCRIPTION")
                        .font(.headline)
                        .fontWeight(.semibold)
                    Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the and industry's standard dummy ")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                }
                .frame(maxWidth: .infinity,alignment: .leading)
                .padding(.vertical,10)
                .padding(.horizontal)
                
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical,5)
                    .padding(.horizontal)
                
                
                
                Spacer()
            }
            .toolbar(.hidden)
        }
    }
}

#Preview {
    SponserDetailView(SponserImg: Image("Sponsor1"), SponserName: "Gladyce jake")
}


extension SponserDetailView {
    private var header: some View{
        
        ZStack{
            HStack{
                Button{
                    dismiss.callAsFunction()
                }label: {
                    Image(systemName: "arrow.left")
                        .foregroundStyle(Color.theme.accent)
                        .font(.title2)
                }
                Spacer()
            }
            
            Text("Sponser")
                .font(.title2)
                .bold()
            
        }
        
    }
}
