//
//  ArtistDetailView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 22/04/24.
//

import SwiftUI

struct ArtistDetailView: View {
    var occupations : [String] = ["Singer","commentary"]
    @Environment(\.dismiss) var dismiss
    var artistImg : Image
    var artistName : String
    var body: some View {
        VStack{
            header
                .padding()
            artistImg
                .resizable()
                .scaledToFit()
                .frame(width: 87,height: 87)
                .padding(.vertical)
            Text(artistName)
                .font(.headline)
                .fontWeight(.semibold)
            //                .padding()
            
            ArtistDetail
            Spacer()
            
        }
        .toolbar(.hidden)
    }
}

#Preview {
    ArtistDetailView(artistImg: Image("Avatar"), artistName: "Gladyce jake")
}

extension ArtistDetailView {

    private var header: some View{
        
        ZStack{
            HStack{
                Button{
                    dismiss.callAsFunction()
                }label: {
                    Image(systemName: "arrow.left")
                        .foregroundStyle(Color.theme.accent)
                        .font(.title2)
                }
                Spacer()
            }
            
            Text("Artist Details")
                .font(.title2)
                .bold()
            
            
        }
        
    }
    
    private var ArtistDetail : some View {
        VStack{
            VStack(alignment : .leading){
                Text("OCCUPTION")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundStyle(Color.theme.accent)
                HStack {
                    ForEach(0..<occupations.count){index in
                            Text(occupations[index])
                            .font(.title3)
                            .foregroundStyle(Color.theme.secondyText)
                            .padding(10)
                            .background(Color.theme.secondory)
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                    }
                }
            }
            .frame(maxWidth: .infinity,alignment: .leading)
            .padding()
            
            Divider()
                .frame(height: 1)
                .background(Color.theme.secondory)
                .padding(.vertical,5)
                .padding(.horizontal)
            
            VStack(alignment : .leading){
                Text("ABOUT US")
                    .font(.headline)
                    .fontWeight(.semibold)
                Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the and industry's standard dummy ")
                    .font(.subheadline)
                    .foregroundStyle(Color.theme.secondyText)
            }
            .frame(maxWidth: .infinity,alignment: .leading)
            .padding(.vertical,10)
            .padding(.horizontal)
            
        }
    }
}
