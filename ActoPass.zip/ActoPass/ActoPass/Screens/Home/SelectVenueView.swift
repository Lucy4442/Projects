//
//  SelectVenueView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 19/04/24.
//

import SwiftUI

struct SelectVenueView: View {
    
    @Environment(\.dismiss) var presentationMode
    var cities : [String] = ["surat","ahemdabad","delhi","mumbai"]
    @State var progress = 1
    @State var currentState = 0
    @State var dateTimeTransition : AnyTransition = .move(edge: .trailing)
    @State var sTickets = 0
    @State var gTickets = 0
    @State var pTickets = 0
    
    @State var isPaymentShow : Bool = false
    
    var body: some View {
        VStack{
            header
                .padding(.horizontal)
            
            progressView
                .padding(.bottom)
                .padding(.horizontal)
            if progress == 1{
                ScrollView(showsIndicators : false){
                    ForEach(0..<cities.count){index in
                        cityVenues(cities[index])
                            .onTapGesture {
                                withAnimation(.easeInOut(duration: 1)) {
                                    progress = 2
                                }
                            }
                    }
                }
                .padding(.horizontal)
                .transition(.move(edge: .leading))
            }else if progress == 2{
                VStack {
                    Date_TimeView()
                    Spacer()
                    Button{
                        dateTimeTransition = .move(edge: .leading)
                        withAnimation(.easeInOut(duration: 1)){
                            progress = 3
                        }
                        
                    }label: {
                        Text("Continue")
                            .font(.title3)
                            .foregroundStyle(.white)
                            .frame(height: 50)
                            .frame(maxWidth: .infinity)
                            .background( Color.theme.purple  )
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .padding()
                    }
                }
                .padding(.top)
                .padding(.horizontal)
                .transition(dateTimeTransition)
                
                
            }else{
                ZStack{
                    ScrollView{
                        VStack(spacing:15){
                            TicketCardView(ticketType: "SILVER", noOfTickets: $sTickets)
                            TicketCardView(ticketType: "GOLD", noOfTickets: $gTickets)
                            TicketCardView(ticketType: "PLATINUM", noOfTickets: $pTickets)
                            Spacer(minLength: 100)
                        }
                        .padding()
                    }
                    navigation
                }
                .transition(.move(edge: .trailing))
            }
        }
        .toolbar(.hidden)
        .ignoresSafeArea(edges: .bottom)
        .navigationDestination(isPresented: $isPaymentShow) {
            PaymentPage()
            
            
        }
    }
}


#Preview {
    SelectVenueView()
}

extension SelectVenueView{
    private var header: some View{
        
        ZStack{
            HStack{
                Button{
                    presentationMode.callAsFunction()
                }label: {
                    Image(systemName: "arrow.left")
                        .foregroundStyle(Color.theme.accent)
                        .font(.title2)
                }
                Spacer()
            }
            
            Text("Bar Crawl, Gurgon")
                .font(.title2)
                .bold()
            
        }
        
    }
    
    private var progressView : some View {
        VStack{
            HStack(spacing : 0){
                Image(progress > 1 ? "progress3" : progress == 1 ? "progress2" : "progress1" )
                Rectangle()
                    .fill(Color.theme.purple)
                    .frame(width:progress > 1 ? ((UIScreen.main.bounds.width - 120) / 2) : 0,height: 2)
                    .frame(width: (UIScreen.main.bounds.width - 120) / 2,alignment: .leading)
                    .background(Color.theme.secondory2)
                
                
                Image(progress > 2 ? "progress3" : progress == 2 ? "progress2" : "progress1" )
                Rectangle()
                    .fill(Color.theme.purple)
                    .frame(width:progress > 2 ? ((UIScreen.main.bounds.width - 120) / 2) : 0,height: 2)
                    .frame(width: (UIScreen.main.bounds.width - 120) / 2,alignment: .leading)
                    .foregroundStyle(Color.theme.secondory2)
                    .background(Color.theme.secondory2)
                
                Image(progress > 3 ? "progress3" : progress == 3 ? "progress2" : "progress1" )
                
            }
            HStack(){
                Text("Venue")
                    .offset(x : 6)
                Spacer()
                Text("Date & Time")
                    .offset(x : 5)
                Spacer()
                Text("Tickets")
                    .offset(x : -5)
            }
            .font(.caption)
            
        }
    }
    
    private func cityVenues(_ city : String) -> some View {
        VStack(alignment : .leading){
            Text(city.uppercased())
                .font(.subheadline)
                .bold()
                .foregroundStyle(Color.theme.purple)
                .multilineTextAlignment(.leading)
            
            
            ForEach(0..<2){ index in
                HStack{
                    Text("HK Hall: \(city.capitalized)")
                    Spacer()
                    Image("RightArrow")
                }
                .font(.title3)
                .bold()
                
                Text("14 September,2023 | 9:00 PM to 12:00 PM")
                    .font(.subheadline)
                    .foregroundStyle(Color.theme.accent)
                Text("New Barakhamba Rd, Connaught Lane, Barakhamba, New Delhi, Delhi 110001")
                    .font(.subheadline)
                    .foregroundStyle(Color.theme.secondyText)
                
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    .padding(.vertical)
            }
            
            
        }
    }
    
    private var tickets: some View{
        ZStack{
            ScrollView{
                VStack{
                    
                }
            }
        }
    }
    
    private var navigation: some View{
        VStack{
            
            Spacer()
            
            HStack{
                VStack(alignment:.leading){
                    Text("\(sTickets+pTickets+gTickets) Tickets")
                        .font(.subheadline)
                        .foregroundStyle(Color.theme.secondyText)
                    
                    Text("$\(Float(sTickets+pTickets+gTickets) * 8.00,specifier: "%.2f")")
                        .font(.title)
                        .foregroundStyle(Color.theme.accent)
                        .bold()
                        .padding(.top,1)
                }
                
                Button{
                    isPaymentShow.toggle()
                } label: {
                    HStack{
                        Text("Proceed")
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .foregroundStyle(.white)
                    .background(Color.theme.purple)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding()
                    
                    
                }
            }
            .padding()
            .background(Color.theme.secondory)
            .clipShape(RoundedRectangle(cornerRadius: 17))
            
        }
        
    }
}

