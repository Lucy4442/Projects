//
//  PaymentPage.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 22/04/24.
//

import SwiftUI

struct PaymentPage: View {
    
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        VStack{
            header
                .padding(.horizontal)
            TicketDetail()
                .padding()
            Spacer()
            
        }
        .toolbar(.hidden)
        
    }
}

#Preview {
    PaymentPage()
}

extension PaymentPage {
    private var header: some View{
        
        ZStack{
            HStack{
                Button{
                    presentationMode.wrappedValue.dismiss()
                }label: {
                    Image(systemName: "arrow.left")
                        .foregroundStyle(Color.theme.accent)
                        .font(.title2)
                }
                Spacer()
            }
            
            Text("Payment")
                .font(.title2)
                .bold()
            
        }
        
    }


}
