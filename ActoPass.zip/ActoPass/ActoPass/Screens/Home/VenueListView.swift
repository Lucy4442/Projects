//
//  VenueListView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 19/04/24.
//

import SwiftUI

struct VenueListView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var showSelectVenue = false
    var body: some View {
        VStack{
            header
            ScrollView{
                ForEach(0..<3){index in
                    VenueCard(showSelectVenue: $showSelectVenue)
                        .padding(.horizontal)
                        .padding(.top,10)
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding(.horizontal)
                }
            }
        }
        .toolbar(.hidden)
        .navigationDestination(isPresented: $showSelectVenue) {
            SelectVenueView()
        }
        
    }
}

#Preview {
    VenueListView()
}

extension VenueListView{
    private var header: some View{
       
            ZStack{
                HStack{
                    Button{
                        presentationMode.wrappedValue.dismiss()
                    }label: {
                        Image(systemName: "arrow.left")
                            .foregroundStyle(Color.theme.accent)
                            .font(.title2)
                    }
                    Spacer()
                }
                
                Text("List of Venues")
                    .font(.title2)
                    .bold()
           
        }

    }
}
