//
//  TicketView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct TicketView: View {
    var body: some View {
        Text("Hello, TicketView!")
    }
}

#Preview {
    TicketView()
}
