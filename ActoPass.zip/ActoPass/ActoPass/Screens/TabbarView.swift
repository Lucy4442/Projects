//
//  HomeView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct TabbarView: View {
    
    @State var selectedIndex = 0
    
    init(){
        UITabBar.appearance().isTranslucent = false
    }
    
    var body: some View {
        
        TabView(selection: $selectedIndex){
           HomeView()
                .tabItem {
                    Image(selectedIndex == 0 ? "SelectedHome" : "Home")
                    Text("Home")
                }
                .tag(0)
            
            ExploreView()
                .tabItem {
                    Image(selectedIndex == 1 ? "SelectedExplore" :"Explore")
                    Text("Explore")
                }
                .tag(1)
            
            TicketView()
                .tabItem {
                    Image(selectedIndex == 2 ? "SelectedTicket" :"Ticket")
                    Text("Ticket")
                }
                .tag(2)
        }
        .toolbar(.hidden)
        .tint(Color.theme.purple)
        .onChange(of: selectedIndex) { oldValue, newValue in
            print(selectedIndex)
        }
    }
}

#Preview {
    TabbarView()
}
