//
//  LoginView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 16/04/24.
//

import SwiftUI

struct LoginView: View {
    
    @State var number : String = ""
    @State var showDetail = false
    @State var showOtpView = false
    @State var offset = 70.0
    var body: some View {
        NavigationStack{
            ZStack{
                VStack{
                    HStack{
                        Image("BC1")
                        Spacer()
                    }
                    HStack{
                        Spacer()
                        Image("BC2")
                    }
                    .offset(y:-60)
                    HStack{
                        Image("BC3")
                        Spacer()
                    }
                    Spacer()
                }
                
                VStack{
                    
                    Spacer()
                    
                    Image("Icon2")
                        .offset(y:offset)
                    
                    Spacer()
                    
                    if showDetail {
                        Text("Sign in or create \n account!")
                            .font(.largeTitle)
                            .foregroundStyle(Color.theme.accent)
                            .bold()
                            .multilineTextAlignment(.center)
                        Text("Enter your mobile number!")
                            .foregroundStyle(Color.theme.secondyText)
                        
                        Spacer()
                        
                        TextField("9999999999", text: $number)
                            .font(.largeTitle)
                            .bold()
                            .keyboardType(.numberPad)
                            .foregroundStyle(Color.theme.accent)
                            .multilineTextAlignment(.center)
                        
                        Spacer()
                        
                        Button{
                            showOtpView.toggle()
                        }label: {
                            Text("Continue")
                                .font(.title3)
                                .foregroundStyle(number.isEmpty ? Color.theme.secondyText : .white)
                                .frame(height: 50)
                                .frame(maxWidth: .infinity)
                                .background(number.isEmpty ? Color.theme.secondory : Color.theme.purple)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                .padding()
                            
                        }
                        Spacer()
                    }
                    
                }
            }
            .toolbar(.hidden)
            .navigationDestination(isPresented: $showOtpView, destination: {
                OtpView()
            })
            .onAppear{
                withAnimation(.bouncy(duration: 1.5)) {
                    showDetail = true
                    offset = 0
                }
            }
        }
    }
}

#Preview {
    LoginView()
}
