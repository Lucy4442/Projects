//
//  LoginWithPasswordView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct LoginWithPasswordView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var password = ""
    @State var continued = false
    @State var showPassword = false
    var body: some View {
            VStack{
                HStack{
                    Button{
                        presentationMode.wrappedValue.dismiss()
                    }label: {
                        Image(systemName: "arrow.left")
                            .foregroundStyle(Color.theme.accent)
                            .font(.title2)
                    }
                    Spacer()
                }
                .padding()
                
                Spacer()
                
                VStack{
                    Image("Lock")
                        .padding(.bottom)
                    Text("+91 1234567890")
                        .foregroundStyle(Color.theme.secondyText)
                        .fontWeight(.bold)
                        .padding(.top)
                    Text("Already Sign up")
                        .font(.largeTitle)
                        .foregroundStyle(Color.theme.accent)
                        .bold()
                        .multilineTextAlignment(.center)
                        .padding(.top,1)
                    Text("Please enter your password")
                        .foregroundStyle(Color.theme.secondyText)
                        .multilineTextAlignment(.center)
                        .font(.headline)
                    
                }
                
                Spacer()
                VStack{
                    HStack(spacing: 10){
                        Image(systemName:"lock.circle")
                            .font(.title2)
                            .foregroundStyle(Color.theme.secondory)
                        
                        if showPassword {
                            TextField("Enter password", text: $password)
                                .font(.headline)
                                .bold()
                                .onChange(of: password) { oldValue, newValue in
                                    if newValue.isEmpty{
                                        continued = false
                                    }else{
                                        continued = true
                                    }
                                }
                        }else{
                            SecureField("**********", text: $password)
                                .font(.headline)
                                .bold()
                                .onChange(of: password) { oldValue, newValue in
                                    if newValue.isEmpty{
                                        continued = false
                                    }else{
                                        continued = true
                                    }
                                }
                        }
                        
                        
                            
                        Button{
                            showPassword.toggle()
                        }label: {
                            Image(systemName: showPassword  ? "eye" : "eye.slash")
                                .foregroundStyle(Color.theme.secondory)
                        }
                    }
                    .padding(.bottom,1)
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        
                    
                }
                .padding()
                
                Spacer()
                
                Button{
//                    showOtpView.toggle()
                }label: {
                    Text("Continue")
                        .font(.title3)
                        .foregroundStyle(continued ? Color.theme.accent : Color.theme.secondyText)
                        .frame(height: 50)
                        .frame(maxWidth: .infinity)
                        .background(continued ? Color.theme.purple : Color.theme.secondory )
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .padding()
                }
                
                
                ZStack{
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    Text("or")
                        .padding(.horizontal, 10)
                        .background(Color.theme.background)
                }
                
                Button{
                    presentationMode.wrappedValue.dismiss()
                }label: {
                    Text("Send OTP?")
                        .bold()
                        .foregroundStyle(Color.theme.purple)
                        .underline(color: Color.theme.purple)
                        .padding()
                }
                
                Spacer()
            }
            .toolbar(.hidden)
        
    }
}

#Preview {
    LoginWithPasswordView()
}
