//
//  CreateProfileView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 17/04/24.
//

import SwiftUI

struct Credentials : Equatable{
    var lName: String = ""
    var fName: String = ""
}

struct CreateProfileView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var fName = ""
    @State var lName = ""
    @State var continued = false
    @State var credentials = Credentials(lName: "", fName:"" )
    @State var goToHome = false
    var body: some View {
        VStack{
            HStack{
                Button{
                    presentationMode.wrappedValue.dismiss()
                }label: {
                    Image(systemName: "arrow.left")
                        .foregroundStyle(Color.theme.accent)
                        .font(.title2)
                }
                Spacer()
            }
            .padding()
            
            Spacer()
            
            VStack{
                Image("Lock")
                    .padding(.bottom)
                Text("+91 1234567890")
                    .foregroundStyle(Color.theme.secondyText)
                    .fontWeight(.bold)
                    .padding(.top)
                Text("Enter Your Username")
                    .font(.largeTitle)
                    .foregroundStyle(Color.theme.accent)
                    .bold()
                    .multilineTextAlignment(.center)
                    .padding(.top,1)
                Text("You’ve been missed!")
                    .foregroundStyle(Color.theme.secondyText)
                    .multilineTextAlignment(.center)
                    .font(.subheadline)
                
            }
            
            Spacer()
            VStack{
                HStack(spacing: 20){
                    Image(systemName:"person")
                        .font(.title2)
                        .foregroundStyle(Color.theme.secondory)
                    
                   
                    TextField("Enter First name", text: $credentials.fName)
                            .font(.headline)
                            .bold()
//                            .keyboardType(.alphabet)
                            .autocorrectionDisabled()
                }
                .padding(.bottom,1)
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    
                Rectangle()
                    .fill(.clear)
                    .frame(maxHeight: 35)
                
                HStack(spacing: 20){
                    Image(systemName:"person")
                        .font(.title2)
                        .foregroundStyle(Color.theme.secondory)
                    
                   
                    TextField("Enter Last name", text: $credentials.lName)
                            .font(.headline)
                            .bold()
                            .autocorrectionDisabled()
                }
                .padding(.bottom,1)
                Divider()
                    .frame(height: 1)
                    .background(Color.theme.secondory)
                    
                
            }
            .padding()
            
            Spacer()
            
            Button{
                    goToHome.toggle()
            }label: {
                Text("Continue")
                    .font(.title3)
                    .bold()
                    .foregroundStyle(continued ? Color.theme.accent : Color.theme.secondyText)
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
                    .background(continued ? Color.theme.purple : Color.theme.secondory )
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .padding()
            }
            
            Spacer()
        }
        .toolbar(.hidden)
        .onChange(of: credentials) { oldValue, newValue in
            if !credentials.fName.isEmpty, !credentials.lName.isEmpty{
                continued = true
            }else{
                continued = false
            }
        }
        .navigationDestination(isPresented: $goToHome) {
            TabbarView()
        }
        
    
}
}

#Preview {
    CreateProfileView()
}
