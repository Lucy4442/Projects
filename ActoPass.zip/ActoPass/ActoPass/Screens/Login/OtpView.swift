//
//  OtpView.swift
//  ActoPass
//
//  Created by kaushik dhandhala on 16/04/24.
//

import SwiftUI

struct OtpView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var otp  = Array(repeating: "", count: 4)
    @State var continued = false
    @FocusState var fieldFocus : Int?
    @State var loginWithPassword = false
    @State var goToProfile = false
    var body: some View {
            VStack{
                HStack{
                    Button{
                        presentationMode.wrappedValue.dismiss()
                    }label: {
                        Image(systemName: "arrow.left")
                            .foregroundStyle(Color.theme.accent)
                            .font(.title2)
                    }
                    Spacer()
                }
                .navigationDestination(isPresented: $goToProfile, destination: {
                    CreateProfileView()
                })
                .padding()
                
                
                Spacer()
                
                VStack{
                    Image("password")
                        .padding(.bottom)
                    Text("+91 1234567890")
                        .foregroundStyle(Color.theme.secondyText)
                        .fontWeight(.bold)
                        .padding(.top)
                    Text("Already Sign up")
                        .font(.largeTitle)
                        .foregroundStyle(Color.theme.accent)
                        .bold()
                        .multilineTextAlignment(.center)
                        .padding(.top,1)
                    Text("Enter the verificationcode we just sent you on \n your phone number")
                        .foregroundStyle(Color.theme.secondyText)
                        .multilineTextAlignment(.center)
                        .font(.subheadline)
                    
                }
                
                Spacer()
                
                HStack(spacing: 20){
                    
                    ForEach(0..<4){index in
                        TextField("", text: $otp[index])
                            .font(.largeTitle)
                            .frame(width: 64,height: 54)
                            .foregroundStyle(Color.theme.secondyText)
                            .keyboardType(.numberPad)
                            .background(Color.theme.secondory)
                            .multilineTextAlignment(.center)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .overlay(content: {
                                if fieldFocus == index{
                                    RoundedRectangle(cornerRadius: 14)
                                        .stroke(Color.theme.purple, lineWidth: 2)
                                }
                                    
                            })
                            .focused($fieldFocus,equals: index)
                            .onChange(of: otp[index]) { oldValue, newValue in
                               
                                if !newValue.isEmpty{
                                    let newOtp = String( (Int(newValue) ?? 0) % 10 )
                                    if oldValue == newOtp {
                                        otp[index] = String( (Int(newValue) ?? 0) / 10 )
                                    }else{
                                        otp[index] = newOtp
                                    }
                                    if fieldFocus == 3{
                                        
                                        fieldFocus = nil
                                    }else{
                                        fieldFocus = (fieldFocus ?? 0) + 1
                                    }
                                }else{
                                    fieldFocus = (fieldFocus ?? 0) - 1
                                }
                                
                                continued = {
                                    let emptyElements = otp.filter{$0.isEmpty}
                                    return emptyElements.isEmpty
                                }()
                                
                            }
                    }
                    
                    
                }
                .padding()
                
                Spacer()
                
                Button{
                    goToProfile.toggle()
                }label: {
                    Text("Continue")
                        .font(.title3)
                        .foregroundStyle(continued ? Color.theme.accent : Color.theme.secondyText)
                        .frame(height: 50)
                        .frame(maxWidth: .infinity)
                        .background(continued ? Color.theme.purple : Color.theme.secondory )
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .padding()
                }
                
                
                ZStack{
                    Divider()
                        .frame(height: 1)
                        .background(Color.theme.secondory)
                        .padding()
                    Text("or")
                        .padding(.horizontal, 10)
                        .background(Color.theme.background)
                }
                
                Button{
                    loginWithPassword.toggle()
                }label: {
                    Text("Login with Password?")
                        .bold()
                        .foregroundStyle(Color.theme.purple)
                        .underline(color: Color.theme.purple)
                        .padding()
                }
                
                Spacer()
            }
            .toolbar(.hidden)
            .navigationDestination(isPresented: $loginWithPassword, destination: {
                LoginWithPasswordView()
            })
        
    }
}

#Preview {
    OtpView()
}
