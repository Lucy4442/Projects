//
//  ContentView.swift
//  LongPressGesture
//
//  Created by mac on 01/04/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        LocalNotification()
    }
}
