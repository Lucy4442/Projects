//
//  CustomeViews.swift
//  LongPressGesture
//
//  Created by mac on 09/04/24.
//

import SwiftUI

enum AllCases : String, CaseIterable {
    case CustomViewModifier = "CustomViewModifier"
    case CustomButtonStyle = "CustomButtonStyle"
    case CustomTransition = "CustomTransition"
    case CustomShape = "CustomShape"
    var destinationView : AnyView {
        switch self {
        case .CustomViewModifier:
            return AnyView(CustomeViewModifier())
        case .CustomButtonStyle:
            return AnyView(CustomeButtonStyle())
        case .CustomTransition:
            return AnyView(CustomeTransition())
        case .CustomShape:
            return AnyView(CustomeShape())
        }
    }
}

struct CustomViews: View {
    var body: some View {
        NavigationView {
            List {
                ForEach(AllCases.allCases, id: \.self) { customView in
                    NavigationLink(destination: customView.destinationView) {
                        Text(customView.rawValue)
                    }
                }
            }
            .navigationTitle("Custom Views")
        }
    }
}

struct CustomeViews_Previews: PreviewProvider {
    static var previews: some View {
        CustomViews()
    }
}
