//
//  CustomeNavBar.swift
//  LongPressGesture
//
//  Created by mac on 10/04/24.
//

import SwiftUI

struct CustomeNavBar: View {
    var body: some View {
        NavigationView{
            ZStack{
                Color.green.ignoresSafeArea()
                NavigationLink {
                    Text("Destination")
                        .navigationTitle("Title 2")
                        .navigationBarBackButtonHidden(false)
                } label: {
                    Text("Navigate")
                }

            }
            .navigationTitle("Nav Title Here")
        }
    }
}

struct CustomeNavBar_Previews: PreviewProvider {
    static var previews: some View {
        CustomeNavBar()
    }
}
