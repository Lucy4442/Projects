//
//  CustomNavBarContainerView.swift
//  LongPressGesture
//
//  Created by mac on 10/04/24.
//

import SwiftUI

struct CustomNavBarContainerView<Content : View>: View {
    
    let content : Content
    
//    init(@ViewBuilder content : () -> Content)
//    {
//        self.content = content()
//    }
//    
    var body: some View {
        VStack(spacing : 0)
        {
            CustomNavBarView()
            Spacer()
        }
    }
}

//struct CustomNavBarContainerView_Previews: PreviewProvider {
//    static var previews: some View {
//        CustomNavBarContainerView()
//    }
//}
