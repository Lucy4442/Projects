//
//  CustomTabBarContainerView.swift
//  LongPressGesture
//
//  Created by mac on 10/04/24.
//

import SwiftUI

//struct Passthrough<Content>: View where Content: View {
//
//    let content: () -> Content
//
//    init(@ViewBuilder content: @escaping () -> Content) {
//        self.content = content
//    }
//
//    var body: some View {
//        content()
//    }
//
//}

struct CustomTabBarContainerView<Content>: View where Content: View {
    
    @Binding var selection : TabBarItem
    let content: () -> Content
    @State var tabs : [TabBarItem] = []
    
    
    
    init(selection: Binding<TabBarItem>, @ViewBuilder content: @escaping () -> Content){
        self._selection = selection
        self.content = content
    }
    
    var body: some View {
        VStack(spacing : 0){
            ZStack{
                content()
            }
            CustomTabBarView(tabs: tabs, selection: $selection)
        }
    }
}

//struct CustomTabBarContainerView_Previews: PreviewProvider {
//    static let tabs: [TabBarItem] = [
//        TabBarItem(iconName: "house", title: "Home", color: .red),
//        TabBarItem(iconName: "heart", title: "Favorites", color: .blue),
//        TabBarItem(iconName: "person", title: "Person", color: .green)
//    ]
//
//    static var previews: some View {
//        CustomTabBarContainerView(selection: .constant(tabs.first!)) {
//            Color.red
//        }
//    }
//}
