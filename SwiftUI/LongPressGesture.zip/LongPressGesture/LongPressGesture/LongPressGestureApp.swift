//
//  LongPressGestureApp.swift
//  LongPressGesture
//
//  Created by mac on 01/04/24.
//

import SwiftUI

@main
struct LongPressGestureApp: App {
    var body: some Scene {
        WindowGroup {
            Searchable()
        }
    }
}
