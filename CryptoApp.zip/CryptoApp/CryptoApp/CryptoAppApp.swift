//
//  CryptoAppApp.swift
//  CryptoApp
//
//  Created by mac on 19/03/24.
//

import SwiftUI

@main
struct CryptoAppApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView{
                HomeView()
                    .navigationBarHidden(true)
            }
        }
    }
}
